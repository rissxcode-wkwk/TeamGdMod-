#include <Geode/binding/LevelSelectLayer.hpp>
#include <Geode/binding/LevelTools.hpp>
#include <Geode/binding/MenuLayer.hpp>
#include <string>
#include <Geode/modify/LevelSelectLayer.hpp>  // IWYU pragma: keep
#include <Geode/modify/LevelTools.hpp>        // IWYU pragma: keep
#include <Geode/modify/MenuLayer.hpp>         // IWYU pragma: keep

#include <jukebox/managers/nong_manager.hpp>

using namespace geode::prelude;
using namespace jukebox;

bool g_disableTitleOverride = false;

// iOS: binding GD 2.2091 belum punya alamat fungsi ini, jadi hook dinonaktifkan di iOS
#ifndef GEODE_IS_IOS
class $modify(LevelTools) {
    // Inlined in 2.206, commented for now
    // static SongInfoObject* getSongObject(int id) {
    //     SongInfoObject* og = LevelTools::getSongObject(id);
    //     if (og == nullptr) {
    //         return og;
    //     }
    //     int searchId = -id - 1;
    //     auto active = jukebox::NongManager::get().getActiveNong(searchId);
    //     if (active.has_value()) {
    //         auto value = active.value();
    //         og->m_songName = value.songName;
    //         og->m_artistName = value.authorName;
    //     }
    //     return og;
    // }

    static std::string getAudioTitle(int id) {
        if (g_disableTitleOverride || !NongManager::get().initialized()) {
            return LevelTools::getAudioTitle(id);
        }
        int searchID = -id - 1;
        std::optional<Nongs*> res = NongManager::get().getNongs(searchID);
        if (res.has_value()) {
            return res.value()->active()->metadata()->name;
        }
        return LevelTools::getAudioTitle(id);
    }
};
#endif  // GEODE_IS_IOS

class $modify(MenuLayer) {
    // Fix for Overcharged Main Menu
    bool init() {
        g_disableTitleOverride = true;
        bool ret = MenuLayer::init();
        g_disableTitleOverride = false;

        return ret;
    }
};

// iOS: binding GD 2.2091 belum punya alamat fungsi ini, jadi hook dinonaktifkan di iOS
#ifndef GEODE_IS_IOS
class $modify(LevelSelectLayer) {
    bool init(int p0) {
        g_disableTitleOverride = true;
        bool ret = LevelSelectLayer::init(p0);
        g_disableTitleOverride = false;
        return ret;
    }
};
#endif  // GEODE_IS_IOS
