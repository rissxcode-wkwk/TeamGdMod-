#include <jukebox/compat/v2.hpp>

#include <jukebox/utils/fs.hpp>
#include <filesystem>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_map>

#include <Geode/Result.hpp>
#include <Geode/loader/Log.hpp>
#include <Geode/loader/Mod.hpp>
#include <Geode/utils/file.hpp>
#include <Geode/utils/general.hpp>
#include <matjson.hpp>

#include <jukebox/compat/compat.hpp>
#include <jukebox/nong/nong.hpp>
#include <jukebox/utils/random_string.hpp>

using namespace geode::prelude;

namespace jukebox {

namespace compat {

namespace v2 {

bool isSongValid(const matjson::Value& s) {
    return s.contains("songName") && s["songName"].isString() && s.contains("authorName") &&
           s["authorName"].isString() && s.contains("path") && s["path"].isString();
}

bool manifestExists() { return jukebox::fs::exists(manifestPath()); }

std::filesystem::path manifestPath() { return jukebox::fs::saveDir() / "nong_data.json"; }

Result<> backupManifest(bool deleteOrig) {
    if (!manifestExists()) {
        return Ok();
    }

    const std::filesystem::path backupDir = jukebox::fs::saveDir() / ".v2-compat-backup";
    bool exists = jukebox::fs::exists(backupDir);
    bool isDir = jukebox::fs::isDirectory(backupDir);

    if (exists && !isDir) {
        GEODE_UNWRAP(jukebox::fs::remove(backupDir).mapErr([backupDir](const std::string& err) {
            return fmt::format("Failed to remove conflicting backup path {}: {}", jukebox::fs::toString(backupDir),
                               err);
        }));
        exists = false;
    }

    if (!exists) {
        GEODE_UNWRAP(jukebox::fs::createDirs(backupDir).mapErr([backupDir](const std::string& err) {
            return fmt::format("Failed to create backup directory {}: {}", jukebox::fs::toString(backupDir), err);
        }));
    }

    const std::filesystem::path filepath = backupDir / "nong_data.json";
    if (jukebox::fs::exists(filepath)) {
        GEODE_UNWRAP(jukebox::fs::remove(filepath).mapErr([filepath](const std::string& err) {
            return fmt::format("Failed to replace backup file {}: {}", jukebox::fs::toString(filepath), err);
        }));
    }

    GEODE_UNWRAP(jukebox::fs::copyFile(manifestPath(), filepath).mapErr([filepath](const std::string& err) {
        return fmt::format("Failed to write backup file {}: {}", jukebox::fs::toString(filepath), err);
    }));

    if (deleteOrig) {
        const auto sourcePath = manifestPath();
        GEODE_UNWRAP(jukebox::fs::remove(sourcePath).mapErr([sourcePath](const std::string& err) {
            return fmt::format("Failed to delete original v2 manifest {}: {}", jukebox::fs::toString(sourcePath), err);
        }));
    }

    return Ok();
}

Result<LocalSong> parseSong(const matjson::Value& i, int id) {
    if (!isSongValid(i)) {
        return Err("Invalid JSON");
    }

    std::filesystem::path path =
        jukebox::fs::fromString(i["path"].asString().unwrap());

    return Ok(
        LocalSong(SongMetadata(id, jukebox::random_string(16), i["songName"].asString().unwrap(),
                               i["authorName"].asString().unwrap(), std::nullopt, i["startOffset"].asInt().unwrapOr(0)),
                  path));
}

Result<LocalSong> getDefault(int id, const std::filesystem::path& defaultPath, const matjson::Value& songs) {
    for (const matjson::Value& i : songs) {
        if (!isSongValid(i)) {
            continue;
        }

        std::filesystem::path path = jukebox::fs::fromString(i["path"].asString().unwrap());
        if (path == defaultPath) {
            return Ok(LocalSong(
                SongMetadata(id, jukebox::random_string(16), i["songName"].asString().unwrap(),
                             i["authorName"].asString().unwrap(), std::nullopt, i["startOffset"].asInt().unwrapOr(0)),
                path));
        }
    }

    return Err("Default song not found");
}

Result<LocalSong> getActive(int id, const std::filesystem::path& activePath, const matjson::Value& songs) {
    for (const matjson::Value& i : songs) {
        if (!isSongValid(i)) {
            continue;
        }

        std::filesystem::path path = jukebox::fs::fromString(i["path"].asString().unwrap());
        if (path == activePath) {
            return Ok(LocalSong(
                SongMetadata(id, jukebox::random_string(16), i["songName"].asString().unwrap(),
                             i["authorName"].asString().unwrap(), std::nullopt, i["startOffset"].asInt().unwrapOr(0)),
                path));
        }
    }

    return Err("Active song not found");
}

Result<std::unordered_map<int, CompatManifest>> parseManifest() {
    if (!manifestExists()) {
        return Err("No manifest exists for V2");
    }

    std::filesystem::path path = manifestPath();

    GEODE_UNWRAP_INTO(matjson::Value json, jukebox::fs::readJson(path).mapErr([](std::string err) {
        return fmt::format("Couldn't parse JSON from file: {}", err);
    }));

    if (!json.contains("version") || !json["version"].isNumber()) {
        return Err("Invalid JSON");
    }

    int version = json["version"].asInt().unwrap();
    if (version < 1 || version > 3) {
        return Err("Invalid JSON");
    }

    if (!json.contains("nongs") || !json["nongs"].isObject()) {
        return Err("Invalid JSON");
    }

    std::unordered_map<int, CompatManifest> ret;

    for (const auto& [key, data] : json["nongs"]) {
        GEODE_UNWRAP_INTO(int id, geode::utils::numFromString<int>(key));

        if (!data.contains("defaultPath") || !data["defaultPath"].isString() || !data.contains("active") ||
            !data["active"].isString() || !data.contains("songs") || !data["songs"].isArray()) {
            log::warn("Skipping id {}, invalid data", id);
            continue;
        }

        std::filesystem::path defaultPath = jukebox::fs::fromString(data["defaultPath"].asString().unwrap());
        std::filesystem::path activePath = jukebox::fs::fromString(data["active"].asString().unwrap());
        matjson::Value songs = data["songs"].asArray().unwrap();

        Result<LocalSong> defaultRes = getDefault(id, defaultPath, songs);
        if (defaultRes.isErr()) {
            log::warn("{}", defaultRes.unwrapErr());
            continue;
        }

        Result<LocalSong> activeRes = getActive(id, activePath, songs);
        if (activeRes.isErr()) {
            log::warn("{}", activeRes.unwrapErr());
            continue;
        }

        LocalSong defaultSong = std::move(defaultRes.unwrap());
        LocalSong activeSong = std::move(activeRes.unwrap());
        std::vector<LocalSong> manifestSongs;

        for (const matjson::Value& i : songs) {
            if (!isSongValid(i)) {
                log::warn("Found invalid song. Skipping...");
                continue;
            }

            std::filesystem::path path = jukebox::fs::fromString(i["path"].asString().unwrap());
            std::string unique;

            if (path == defaultPath) {
                unique = defaultSong.metadata()->uniqueID;
            } else if (path == activePath) {
                unique = activeSong.metadata()->uniqueID;
            } else {
                unique = jukebox::random_string(16);
            }

            manifestSongs.push_back(LocalSong(
                SongMetadata(id, unique, i["songName"].asString().unwrap(), i["authorName"].asString().unwrap(),
                             std::nullopt, i["startOffset"].asInt().unwrapOr(0)),
                path));
        }

        ret.insert(
            {id, CompatManifest{
                     .id = id, .defaultSong = defaultSong, .active = activeSong, .songs = std::move(manifestSongs)}});
    }

    return Ok(ret);
}

}  // namespace v2

}  // namespace compat

}  // namespace jukebox
