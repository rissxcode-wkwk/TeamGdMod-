#include <jukebox/ui/list/nong_list.hpp>

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <memory>
#include <optional>
#include <string_view>
#include <unordered_set>

#include <Geode/cocos/base_nodes/CCNode.h>
#include <Geode/cocos/cocoa/CCObject.h>
#include <Geode/cocos/menu_nodes/CCMenu.h>
#include <Geode/cocos/platform/CCPlatformMacros.h>
#include <fmt/core.h>
#include <Geode/loader/Event.hpp>
#include <Geode/loader/Log.hpp>
#include <Geode/ui/Label.hpp>
#include <Geode/ui/Layout.hpp>
#include <Geode/ui/LoadingSpinner.hpp>
#include <Geode/ui/ScrollLayer.hpp>
#include <Geode/ui/SimpleAxisLayout.hpp>
#include <Geode/ui/TextInput.hpp>
#include <Geode/utils/cocos.hpp>
#include <asp/iter/std.hpp>

#include <jukebox/events/indexes_loaded.hpp>
#include <jukebox/events/nong_deleted.hpp>
#include <jukebox/events/song_download_finished.hpp>
#include <jukebox/managers/index_manager.hpp>
#include <jukebox/managers/nong_manager.hpp>
#include <jukebox/nong/index.hpp>
#include <jukebox/nong/nong.hpp>
#include <jukebox/ui/list/nong_cell.hpp>
#include <jukebox/ui/list/song_cell.hpp>
#include <jukebox/utils/fs.hpp>

using namespace geode::prelude;

namespace jukebox {

bool NongList::init(std::vector<int> songIds, const CCSize& size, const std::optional<int> levelID,
                    geode::Function<void(std::optional<int>)> onListTypeChange) {
    if (!CCNode::init()) {
        return false;
    }

    this->addEventListener(event::IndexesLoaded(), [&]() { return this->onIndexesLoaded(); });

    m_songIds = std::move(songIds);
    m_levelID = levelID;
    m_onListTypeChange = std::move(onListTypeChange);

    if (m_songIds.size() == 1) {
        m_currentSong = m_songIds.front();
    }

    m_downloadFinishedListener = event::SongDownloadFinished().listen(
        [this](const event::SongDownloadFinishedData& event) { return this->onDownloadFinish(event); });
    m_nongDeletedListener =
        event::NongDeleted().listen([this](const event::NongDeletedData& event) { return this->onNongDeleted(event); });
    m_nongAddedListener = event::ManualSongAdded().listen(
        [this](const event::ManualSongAddedData& event) { return this->onSongAdded(event); });

    this->setContentSize(size);
    this->setAnchorPoint({0.5f, 0.5f});
    this->setID("NongList");

    m_bg = NineSlice::create("square02b_001.png");
    m_bg->setColor({0, 0, 0});
    m_bg->setOpacity(75);
    m_bg->setScale(0.3f);
    m_bg->setContentSize(size / m_bg->getScale());
    m_bg->setID("background");
    this->addChildAtPosition(m_bg, Anchor::Center);

    m_backMenu = CCMenu::create();
    auto spr = CCSprite::createWithSpriteFrameName("backArrowPlain_01_001.png");
    auto backBtn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(NongList::onBack));
    m_backBtn = backBtn;
    m_backBtn->setID("back-btn");
    m_backBtn->setVisible(false);
    m_backMenu->addChild(backBtn);
    m_backMenu->setContentWidth(backBtn->getContentWidth());
    m_backMenu->setContentHeight(size.height);
    m_backMenu->setLayout(SimpleColumnLayout::create()->setGap(1.0f)->setMainAxisScaling(AxisScaling::ScaleDown));
    m_backMenu->setZOrder(1);
    m_backMenu->setID("back-menu");
    this->addChildAtPosition(m_backMenu, Anchor::Left, CCPoint{-10.0f, 0.0f});

    m_searchInput = TextInput::create(size.width - s_padding * 2, "Search NONGs...");
    m_searchInput->setID("search-input");
    m_searchInput->setScale(0.75f);
    m_searchInput->setCallback([this](const std::string& query) {
        m_searchQuery = query;
        this->build();
    });
    m_searchInput->setVisible(false);
    this->addChildAtPosition(m_searchInput, Anchor::Top, CCPoint{0.0f, -(s_searchBarHeight / 2 + s_padding / 2)});

    m_list = ScrollLayer::create({size.width, size.height - s_padding});
    m_list->m_contentLayer->setLayout(SimpleColumnLayout::create()
                                          ->setMainAxisDirection(AxisDirection::TopToBottom)
                                          ->setMainAxisAlignment(MainAxisAlignment::Start)
                                          ->setMainAxisScaling(AxisScaling::Grow)
                                          ->ignoreInvisibleChildren(false)
                                          ->setGap(s_padding / 2));
    m_list->setID("list");

    this->addChildAtPosition(m_list, Anchor::Center, -m_list->getScaledContentSize() / 2);

    m_onListTypeChange(m_currentSong);

    this->build();
    return true;
}

bool NongList::matchesSearch(const std::string_view name) const {
    if (m_searchQuery.empty()) {
        return true;
    }

    auto it = std::search(name.begin(), name.end(), m_searchQuery.begin(), m_searchQuery.end(),
                          [](unsigned char u1, unsigned char u2) { return std::tolower(u1) == std::tolower(u2); });

    return it != name.end();
}

void NongList::build() {
    if (m_list->m_contentLayer->getChildrenCount() > 0) {
        m_list->m_contentLayer->removeAllChildrenWithCleanup(true);
    }

    if (m_songIds.empty()) {
        return;
    }

    CCSize itemSize = {m_list->getScaledContentSize().width - s_padding, s_itemSize};

    if (m_onListTypeChange) {
        m_onListTypeChange(m_currentSong);
    }

    if (!m_currentSong) {
        // Multi-song view

        m_searchInput->setVisible(false);
        m_list->setContentSize({m_list->getContentSize().width, this->getContentSize().height - s_padding});
        m_list->updateAnchoredPosition(Anchor::Center, -m_list->getScaledContentSize() / 2);

        for (int id : m_songIds) {
            std::optional<Nongs*> nongs = NongManager::get().getNongs(id);

            if (!nongs) {
                continue;
            }

            Song* active = nongs.value()->active();

            m_list->m_contentLayer->addChild(
                SongCell::create(id, active->metadata(), itemSize, [this, id]() { this->onSelectSong(id); }));
        }
    } else {
        // Single item

        m_searchInput->setVisible(true);
        float listHeight = this->getContentSize().height - s_padding - s_searchBarHeight;
        m_list->setContentSize({m_list->getContentSize().width, listHeight});
        m_list->updateAnchoredPosition(Anchor::Center,
                                       CCPoint{0.0f, -(s_searchBarHeight / 2)} - m_list->getScaledContentSize() / 2);

        int id = m_currentSong.value();

        std::optional<Nongs*> optNongs = NongManager::get().getNongs(id);
        if (!optNongs) {
            return;
        }

        Nongs* nongs = optNongs.value();
        LocalSong* defaultSong = nongs->defaultSong();
        std::string defaultID = defaultSong->metadata()->uniqueID;
        Song* active = nongs->active();

        m_list->m_contentLayer->addChild(NongCell::create(id, defaultID, itemSize, m_levelID, std::nullopt));

        geode::Label* localSongs = geode::Label::create("Stored NONGs", "goldFont.fnt");
        localSongs->setID("local-section");
        localSongs->setScale(0.5f);
        m_list->m_contentLayer->addChild(localSongs);

        std::unordered_set<std::string> localYt;
        std::unordered_set<std::string> localHosted;

        if (nongs->locals().empty() && nongs->youtube().empty() && nongs->hosted().empty()) {
            this->addNoLocalSongsNotice();
        }

        std::vector<Song*> allLocalNongs;
        allLocalNongs.reserve(nongs->locals().size() + nongs->youtube().size() + nongs->hosted().size());

        for (std::unique_ptr<LocalSong>& nong : nongs->locals()) {
            allLocalNongs.push_back(nong.get());
        }

        for (std::unique_ptr<YTSong>& nong : nongs->youtube()) {
            allLocalNongs.push_back(nong.get());
            if (nong->indexID().has_value()) {
                localYt.insert(fmt::format("{}|{}", nong->indexID().value(), nong->metadata()->uniqueID));
            }
        }

        for (std::unique_ptr<HostedSong>& nong : nongs->hosted()) {
            allLocalNongs.push_back(nong.get());
            if (nong->indexID().has_value()) {
                localHosted.insert(fmt::format("{}|{}", nong->indexID().value(), nong->metadata()->uniqueID));
            }
        }

        std::vector<std::string> verifiedNongs = m_levelID.has_value() ? NongManager::get().getVerifiedNongsForLevel(
                                                                             m_levelID.value(), {m_currentSong.value()})
                                                                       : std::vector<std::string>{};

        std::ranges::sort(allLocalNongs, [verifiedNongs](Song* a, Song* b) {
            auto sourcePriority = [](Song* s) {
                if (typeinfo_cast<LocalSong*>(s)) {
                    return 0;
                }
                if (typeinfo_cast<HostedSong*>(s)) {
                    return 1;
                }
                if (typeinfo_cast<YTSong*>(s)) {
                    return 2;
                }
                return 3;
            };

            bool aVerified =
                asp::iter::from(verifiedNongs).any([a](auto& i) { return i == a->metadata()->uniqueID; });
            bool bVerified =
                asp::iter::from(verifiedNongs).any([b](auto& i) { return i == b->metadata()->uniqueID; });

            // Sort by Verified
            if (aVerified != bVerified) {
                return aVerified;
            }

            // Then by source priority
            int sourceA = sourcePriority(a);
            int sourceB = sourcePriority(b);
            if (sourceA != sourceB) {
                return sourceA < sourceB;
            }

            // Then by name
            return a->metadata()->name < b->metadata()->name;
        });

        for (Song* nong : allLocalNongs) {
            if (!this->matchesSearch(nong->metadata()->name) && !this->matchesSearch(nong->metadata()->artist)) {
                continue;
            }
            this->addSongToList(nong, nongs);
        }

        geode::Label* indexLabel = geode::Label::create("Download nongs", "goldFont.fnt");
        indexLabel->setID("index-section");
        indexLabel->setScale(0.5f);
        m_list->m_contentLayer->addChild(indexLabel);

        if (IndexManager::get().fetchingIndexes()) {
            CCNode* indexFetchingNode = CCNode::create();
            indexFetchingNode->setID("index-fetching-node");
            indexFetchingNode->setContentSize({178.0f, 20.0f});
            indexFetchingNode->addChild(LoadingSpinner::create(25.0f));
            Label* label = Label::create("Fetching indexes...", "bigFont.fnt");
            indexFetchingNode->addChild(label);
            indexFetchingNode->setLayout(SimpleRowLayout::create()
                                             ->setGap(3.0f)
                                             ->setMainAxisScaling(AxisScaling::Scale)
                                             ->setCrossAxisScaling(AxisScaling::Scale));

            m_list->m_contentLayer->addChild(indexFetchingNode);
        } else {
            std::vector<index::IndexSongMetadata*> allIndexNongs;
            // Might reserve more than needed, still fine imo
            allIndexNongs.reserve(nongs->indexSongs().size());

            for (index::IndexSongMetadata* index : nongs->indexSongs()) {
                const std::string id = fmt::format("{}|{}", index->parentID->m_id, index->uniqueID);

                if (index->ytId.has_value() && localYt.contains(id)) {
                    continue;
                }

                if (index->url.has_value() && localHosted.contains(id)) {
                    continue;
                }

                allIndexNongs.push_back(index);
            }

            std::sort(allIndexNongs.begin(), allIndexNongs.end(),
                      [this](index::IndexSongMetadata* a, index::IndexSongMetadata* b) {
                          auto sourcePriority = [](index::IndexSongMetadata* s) {
                              if (s->url.has_value()) {
                                  return 0;
                              }
                              if (s->ytId.has_value()) {
                                  return 1;
                              }
                              return 2;
                          };

                          bool aVerified = m_levelID.has_value()
                                               ? std::find(a->verifiedLevelIDs.begin(), a->verifiedLevelIDs.end(),
                                                           m_levelID.value()) != a->verifiedLevelIDs.end()
                                               : false;
                          bool bVerified = m_levelID.has_value()
                                               ? std::find(b->verifiedLevelIDs.begin(), b->verifiedLevelIDs.end(),
                                                           m_levelID.value()) != b->verifiedLevelIDs.end()
                                               : false;

                          // Sort by Verified
                          if (aVerified != bVerified) {
                              return aVerified;
                          }

                          // Then by source priority
                          int sourceA = sourcePriority(a);
                          int sourceB = sourcePriority(b);
                          if (sourceA != sourceB) {
                              return sourceA < sourceB;
                          }

                          // Then by name
                          return a->name < b->name;
                      });

            uint32_t inserted = 0;
            for (index::IndexSongMetadata* indexNong : allIndexNongs) {
                if (!this->matchesSearch(indexNong->name) && !this->matchesSearch(indexNong->artist)) {
                    continue;
                }
                inserted++;
                this->addIndexSongToList(indexNong, nongs);
            }

            if (inserted == 0) {
                std::string message = "No downloadable NONGs for this song";
                if (!m_searchQuery.empty() && !allIndexNongs.empty()) {
                    message = "No NONGs match this search query";
                }

                geode::Label* label = geode::Label::create(message.c_str(), "bigFont.fnt");
                label->setID("no-index-songs");
                label->setLimitLabelWidth(150.0f, 0.7f, 0.1f);
                m_list->m_contentLayer->addChild(label);
            }
        }
    }
    m_list->m_contentLayer->updateLayout();
    this->scrollToTop();
}

void NongList::addSongToList(Song* nong, Nongs* parent, bool liveInsert) {
    int id = m_currentSong.value();
    Song* defaultSong = parent->defaultSong();
    Song* active = parent->active();

    CCSize itemSize = {m_list->getScaledContentSize().width - s_padding, s_itemSize};

    std::string uniqueID = nong->metadata()->uniqueID;
    std::optional<std::filesystem::path> path = nong->path();
    bool isFromIndex = nong->indexID().has_value();
    bool isDownloaded = path.has_value() && jukebox::fs::exists(path.value());
    NongCell* cell = NongCell::create(id, uniqueID, itemSize, m_levelID, std::nullopt);
    cell->setID(uniqueID);

    if (!liveInsert) {
        m_list->m_contentLayer->addChild(cell);
        return;
    }

    CCNode* indexSection = m_list->m_contentLayer->getChildByID("index-section");

    if (indexSection) {
        m_list->m_contentLayer->insertBefore(cell, indexSection);
    } else {
        m_list->m_contentLayer->addChild(cell);
    }
}

void NongList::addIndexSongToList(index::IndexSongMetadata* song, Nongs* parent) {
    const CCSize itemSize = {m_list->getScaledContentSize().width - s_padding, s_itemSize};
    NongCell* cell = NongCell::create(m_currentSong.value(), song->uniqueID, itemSize, m_levelID, song);
    cell->setID(fmt::format("{}-{}", song->parentID->m_id, song->uniqueID));
    m_list->m_contentLayer->addChild(cell);
}

void NongList::addNoLocalSongsNotice(bool liveInsert) {
    geode::Label* label = geode::Label::create("You have no stored NONGs :(", "bigFont.fnt");
    label->setID("no-local-songs");
    label->setLimitLabelWidth(150.0f, 0.7f, 0.1f);

    if (!liveInsert) {
        m_list->m_contentLayer->addChild(label);
    } else {
        CCNode* section = m_list->m_contentLayer->getChildByID("local-section");
        if (!section) {
            log::error("Couldn't insert no local songs notice. Section not found");
        } else {
            m_list->m_contentLayer->insertAfter(label, section);
        }
    }
}

void NongList::scrollToTop() {
    m_list->m_contentLayer->setPositionY(-m_list->m_contentLayer->getContentHeight() + m_list->getContentHeight());
}

void NongList::onBack(cocos2d::CCObject* target) {
    if (!m_currentSong.has_value() || m_songIds.size() < 2) {
        return;
    }

    // Multi-song view has no search
    m_searchQuery = "";
    if (m_searchInput) {
        m_searchInput->setString("");
    }

    m_currentSong = std::nullopt;
    this->build();
    this->scrollToTop();
    m_backBtn->setVisible(false);
    m_backMenu->updateLayout();
}

void NongList::setCurrentSong(int songId) {
    if (std::find(m_songIds.begin(), m_songIds.end(), songId) != m_songIds.end()) {
        m_currentSong = songId;
    }
}

void NongList::onSelectSong(int songId) {
    if (m_currentSong.has_value() || std::find(m_songIds.begin(), m_songIds.end(), songId) == m_songIds.end()) {
        return;
    }

    m_currentSong = songId;
    this->build();
    this->scrollToTop();
    m_backBtn->setVisible(true);
    m_backMenu->updateLayout();
}

ListenerResult NongList::onDownloadFinish(const event::SongDownloadFinishedData& e) {
    if (!m_list || !m_currentSong.has_value() || !e.indexSource().has_value()) {
        return ListenerResult::Propagate;
    }

    std::optional<Nongs*> optNongs = NongManager::get().getNongs(m_currentSong.value());

    if (!optNongs.has_value()) {
        return ListenerResult::Propagate;
    }

    Nongs* nongs = std::move(optNongs).value();

    if (!nongs->findSong(e.destination()->metadata()->uniqueID)) {
        return ListenerResult::Propagate;
    }

    index::IndexSongMetadata* meta = e.indexSource().value();
    if (CCNode* i = m_list->m_contentLayer->getChildByID(fmt::format("{}-{}", meta->parentID->m_id, meta->uniqueID))) {
        i->removeFromParentAndCleanup(true);
    }

    this->addSongToList(e.destination(), nongs, true);

    // Remove "you have no local songs label"
    if (auto node = m_list->m_contentLayer->getChildByID("no-local-songs")) {
        node->removeFromParentAndCleanup(true);
    }

    this->updateLayoutAndFixWeirdDisplay();

    return ListenerResult::Propagate;
}

ListenerResult NongList::onNongDeleted(const event::NongDeletedData& e) {
    if (!m_list || !m_currentSong.has_value() || m_currentSong.value() != e.gdId()) {
        return ListenerResult::Propagate;
    }

    if (CCNode* found = m_list->m_contentLayer->getChildByID(e.uniqueId())) {
        found->removeFromParentAndCleanup(true);
        this->updateLayoutAndFixWeirdDisplay();
    }

    std::optional<Nongs*> optNongs = NongManager::get().getNongs(m_currentSong.value());

    if (!optNongs.has_value()) {
        return ListenerResult::Propagate;
    }

    Nongs* nongs = optNongs.value();

    for (index::IndexSongMetadata* i : nongs->indexSongs()) {
        if (i->uniqueID != e.uniqueId()) {
            continue;
        }

        if (!m_list->m_contentLayer->getChildByID("index-section")) {
            geode::Label* indexLabel = geode::Label::create("Download NONGs", "goldFont.fnt");
            indexLabel->setID("index-section");
            indexLabel->setScale(0.5f);
            m_list->m_contentLayer->addChild(indexLabel);
        }

        this->addIndexSongToList(i, nongs);
    }

    this->updateLayoutAndFixWeirdDisplay();

    return ListenerResult::Propagate;
}

ListenerResult NongList::onIndexesLoaded() {
    if (!m_list || !m_currentSong.has_value()) {
        return ListenerResult::Propagate;
    }

    this->build();
    return ListenerResult::Propagate;
}

ListenerResult NongList::onSongAdded(const event::ManualSongAddedData& e) {
    if (!m_list || !m_currentSong.has_value() || m_currentSong.value() != e.nongs()->songID()) {
        return ListenerResult::Propagate;
    }

    this->addSongToList(e.song(), e.nongs(), true);

    // Remove "you have no local songs label"
    if (auto node = m_list->m_contentLayer->getChildByID("no-local-songs")) {
        node->removeFromParentAndCleanup(true);
    }

    this->updateLayoutAndFixWeirdDisplay();
    return ListenerResult::Propagate;
}

void NongList::updateLayoutAndFixWeirdDisplay() const {
    m_list->m_contentLayer->updateLayout();
    m_list->m_contentLayer->setPositionY(m_list->m_contentLayer->getPositionY() + 0.00001f);
}

NongList* NongList::create(std::vector<int> songIds, const cocos2d::CCSize& size, std::optional<int> levelID,
                           geode::Function<void(std::optional<int>)> onListTypeChange) {
    auto ret = new NongList();
    if (ret->init(std::move(songIds), size, levelID, std::move(onListTypeChange))) {
        ret->autorelease();
        return ret;
    }

    delete ret;
    return nullptr;
}

}  // namespace jukebox
