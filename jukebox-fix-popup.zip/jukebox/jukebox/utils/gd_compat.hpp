#pragma once

#include <filesystem>
#include <functional>
#include <string>

#include <Geode/Geode.hpp>
#include <jukebox/utils/platform.hpp>
#include <Geode/binding/FLAlertLayer.hpp>
#include <Geode/binding/FLAlertLayerProtocol.hpp>
#include <Geode/binding/LevelTools.hpp>
#include <Geode/binding/MusicDownloadManager.hpp>
#include <Geode/binding/SongInfoObject.hpp>

// Wrapper agar iOS (bindings GD 2.2091 belum punya alamat beberapa fungsi)
// tidak menghasilkan "undefined symbol" saat linking.
#ifdef JB_IS_IOS
#pragma message("jukebox gd_compat: iOS shim ACTIVE")
#else
#pragma message("jukebox gd_compat: native GD calls")
#endif

namespace jukebox::gd {

inline std::string pathForSong(int id) {
#ifdef JB_IS_IOS
    std::string base = std::string(cocos2d::CCFileUtils::sharedFileUtils()->getWritablePath2());
    return (std::filesystem::path(base) / (std::to_string(id) + ".mp3")).string();
#else
    return MusicDownloadManager::sharedState()->pathForSong(id);
#endif
}

inline SongInfoObject* getSongInfoObject(int id) {
#ifdef JB_IS_IOS
    (void)id;
    return nullptr;
#else
    return MusicDownloadManager::sharedState()->getSongInfoObject(id);
#endif
}

inline void getSongInfo(int id, bool refresh) {
#ifdef JB_IS_IOS
    (void)id;
    (void)refresh;
#else
    MusicDownloadManager::sharedState()->getSongInfo(id, refresh);
#endif
}

inline std::string getAudioFileName(int id) {
#ifdef JB_IS_IOS
    (void)id;
    return "";
#else
    return LevelTools::getAudioFileName(id);
#endif
}

// Pengganti geode::createQuickPopup: simbolnya (versi ZStringView) tidak ada di loader
// Geode yang lebih lama -> "cannot locate symbol". Ini hanya memakai FLAlertLayer dari bindings.
class QuickPopupDelegate : public FLAlertLayerProtocol {
public:
    std::function<void(FLAlertLayer*, bool)> m_callback;

protected:
    void FLAlert_Clicked(FLAlertLayer* layer, bool btn2) override {
        auto cb = std::move(m_callback);
        if (cb) {
            cb(layer, btn2);
        }
        delete this;
    }
};

inline FLAlertLayer* quickPopup(std::string const& title, std::string const& content, std::string const& btn1,
                                std::string const& btn2, std::function<void(FLAlertLayer*, bool)> callback) {
    auto* delegate = new QuickPopupDelegate();
    delegate->m_callback = std::move(callback);
    auto* alert = FLAlertLayer::create(delegate, title.c_str(), content, btn1.c_str(), btn2.c_str(), 350.f, false, 0.f, 1.f);
    alert->show();
    return alert;
}

}  // namespace jukebox::gd
